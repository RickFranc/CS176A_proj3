// Cited code from http://www.linuxhowtos.org/data/6/client_udp.c
// It seems the code may have been written by Sasha Nitsch, although it is unclear
// Cited code is marked below, mostly to set up the basic parts of the udp client

/* START CITED CODE */

/* UDP client in the internet domain */
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/time.h>

void error(const char *);

/* END CITED CODE */
int getSeqNum(const char *msg){
  int foundSeq = 0;
  int seq = 0;
  for(int i = 0; i < 256; i++){
    if(msg[i] == ' '){
      if(foundSeq) return seq;
      foundSeq = 1;
    }else if(foundSeq){
      seq *= 10;
      seq += msg[i]-'0';
    }
  }
  return seq;
}

/* START CITED CODE */

int main(int argc, char *argv[])
{
   int sock, n;
   unsigned int length;
   struct sockaddr_in server, from;
   struct hostent *hp;
   char buffer[256];
   
   if (argc != 3) { printf("Usage: server port\n");
                    exit(1);
   }
   sock= socket(AF_INET, SOCK_DGRAM, 0);
   if (sock < 0) error("socket");

   server.sin_family = AF_INET;
   hp = gethostbyname(argv[1]);
   if (hp==0) error("Unknown host");

   bcopy((char *)hp->h_addr, 
        (char *)&server.sin_addr,
         hp->h_length);
   server.sin_port = htons(atoi(argv[2]));
   length=sizeof(struct sockaddr_in);
   /*END CITED CODE */
   
   struct timeval timeout;
   timeout.tv_sec = 1;
   timeout.tv_usec = 0;
   if (setsockopt(sock, SOL_SOCKET, SO_RCVTIMEO,&timeout,sizeof(timeout)) < 0) {
     perror("Error");
   }

   int numPackets = 10, numReceived = 0, percenLoss = 0;
   double minTime = 1000, avgTime = 0, maxTime = 0, totalTime = 0;
   int seqNum = 0;
   struct timeval stop, start;
   int seq;
   printf("Beginning...\n");
   do{
     gettimeofday(&start, NULL);
     sprintf(buffer, "PING %i %i", seqNum,(int)(start.tv_sec));
     n=sendto(sock,buffer,
	      strlen(buffer),0,(const struct sockaddr *)&server,length);
     if (n < 0) error("Sendto");
     bzero(buffer,256);
     n = recvfrom(sock, buffer,256, 0,
		  (struct sockaddr *) &from, &length);
     if(n < 0){
       //Timeout
       printf("PING timed out\n");
     }else{
       gettimeofday(&stop, NULL);
       seq = getSeqNum(buffer);
       double time = (stop.tv_sec - start.tv_sec)*1000+(stop.tv_usec-start.tv_usec)/1000.0;
       if(time < minTime) minTime = time;
       if(time > maxTime) maxTime = time;
       totalTime += time;
       numReceived++;
       printf("PING received from %s: seq#=%i time=%f ms\n",argv[1], seq, time);
     }
     seqNum++;
     int pause = 1;
     while(pause){
       gettimeofday(&stop, NULL);
       if((stop.tv_sec - start.tv_sec)*1000+(stop.tv_usec-start.tv_usec)/1000.0 > 1000){
	 //Wait roughly a second between pings
	 pause = 0;
       }
     }
   }while(seqNum < 10);
   percenLoss = (int)((numPackets - numReceived)*1.0/ numPackets * 100);
   avgTime = totalTime/numPackets;
   printf("--- ping statistics --- %i packets transmitted, %i received, %i%% packet loss rtt min/avg/max = %f %f %f ms\n", numPackets, numReceived, percenLoss, minTime, avgTime, maxTime);
   /*START CITED CODE */
   close(sock);
   return 0;
}

void error(const char *msg)
{
    perror(msg);
    exit(0);
}
/*END CITED CODE */
